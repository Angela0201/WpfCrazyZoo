﻿namespace CrazyZoo.Domain.Models
{
    public enum AnimalKind
    {
        Cat = 0,
        Dog = 1,
        Bird = 2
    }
}